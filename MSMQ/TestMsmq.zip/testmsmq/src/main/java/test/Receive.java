package test;

import java.util.ArrayList;

import ionic.Msmq.Message;
import ionic.Msmq.MessageQueueException;
import ionic.Msmq.Queue;

public class Receive {
	public static void main(String[] args) {
		int index  = 0;
		try {
			
			String fullname = "direct=tcp:192.168.206.143\\private$\\myqueue";
			Queue queue = new Queue(fullname);
			
			ArrayList<String> array = new ArrayList<String>() ;
//			while(true) {
			try {
				
				for (int i = 0; i < 1; i++) {
					Message message=queue.receive();
				array.add(message.getBodyAsString());
				System.out.printf("���쪺�� %d���T�� : %s%n",++index,message.getBodyAsString());
//				System.out.println(message);
//				System.out.println(message.getBodyAsString());
//				System.out.println(message.getLabel());
				}

//				int index  = 0;
//				for(String msg : array) {
//					
//					System.out.printf("���쪺�� %d���T�� : %s%n",++index,msg);
//				}
//			System.out.println(array);
			} catch (Exception e) {
//				int index  = 0;
//				for(String msg : array) {
//					
//					System.out.printf("���쪺�� %d���T�� : %s%n",++index,msg);
//				}
				System.out.println("�L��C�T��");
			}
			Thread.sleep(2000);
//		} 
		}catch (MessageQueueException ex1) {
			System.out.println("Put failure:"+ ex1.toString());
			ex1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
