package test;

import java.util.ArrayList;

import ionic.Msmq.Message;
import ionic.Msmq.Queue;

public class testtest {
public static void main(String[] args) {
	System.out.println(System.getProperty("java.library.path"));
	try {
		
		String fullname= ".\\private$\\myqueue02";
//	    String qLabel="Created by testtest.java";
//	    boolean transactional= false;  
//	    Queue queue= Queue.create(fullname, qLabel, transactional);
	    
	    Queue queue = new Queue(fullname);
//		String fullname = "direct=tcp:192.168.201.221\\private$\\myqueue01";
//		Queue queue = new Queue(fullname);
		System.out.println("���\");
//		Message msg=queue.receive();
//		ArrayList<Message> list =new ArrayList<Message>();
	} catch (Exception e) {
		System.out.println("�S���\");
	}
}
}
