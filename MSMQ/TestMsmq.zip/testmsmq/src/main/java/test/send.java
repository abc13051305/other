package test;

import java.util.UUID;

import ionic.Msmq.Message;
import ionic.Msmq.MessageQueueException;
import ionic.Msmq.Queue;

public class send {

	public static void main(String[] args) throws MessageQueueException {
		try {
			String fullname = "direct=tcp:192.168.201.221\\private$\\myqueue";
			Queue queue = new Queue(fullname);
			String label = "testSend03";
			String body = "Hello, World";
			String correlationID = "123";
//			Message msg = new Message(body, label, correlationID);
//
//			queue.send(msg);
//			System.out.println("���榨�\!");
			
			for(int index =0; index < 10; index++) {
					label = UUID.randomUUID().toString();
					body = String.format("SEND MSG : %s , Datalength : %s", label, label.length());
					correlationID = label;
					Message msg2 = new Message(body,label,correlationID);
					queue.send(msg2);
					System.out.printf("Round :%d, ���\�o�e  %s%n", index, new String(msg2.getBody()));
			}
			
		} catch (MessageQueueException ex1) {
			ex1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
