package test;
import java.util.logging.Logger;
public class Libpath {
	



	    static Logger logger = Logger.getLogger(Libpath.class.getName());
	    public static void main(String[] args) {
	    logger.info(System.getProperty("java.library.path"));
	    }
}
