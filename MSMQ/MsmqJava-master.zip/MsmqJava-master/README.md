# MsmqJava
Port of MsmqJava to VS2013 
------------
###Original Code
https://msmqjava.codeplex.com/

In the releases the dll for 64bit support can be downloaded along with the last version of the library (1.2)

Requires vc++ 2013 runtime for 64 bit to be installed


###License 
Microsoft Public License (Ms-PL)
